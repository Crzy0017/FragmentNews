package com.example.fragmentnews

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment

class news_list : Fragment(R.layout.fragment_news) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val new1 = view.findViewById<TextView>(R.id.news_1)
        val temp1: News = news[0]
        new1.text = temp1.header
        new1.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp1))
                addToBackStack(null)
                commit()
            }
        }
        val new2 = view.findViewById<TextView>(R.id.news_2)
        val temp2: News = news[0]
        new2.text = temp2.header
        new2.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp2))
                addToBackStack(null)
                commit()
            }
        }
        val new3 = view.findViewById<TextView>(R.id.news_3)
        val temp3: News = news[2]
        new3.text = temp1.header
        new3.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp3))
                addToBackStack(null)
                commit()
            }
        }
        val new4 = view.findViewById<TextView>(R.id.news_4)
        val temp4: News = news[3]
        new4.text = temp4.header
        new4.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp4))
                addToBackStack(null)
                commit()
            }
        }
        val new5 = view.findViewById<TextView>(R.id.news_5)
        val temp5: News = news[4]
        new5.text = temp1.header
        new5.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp5))
                addToBackStack(null)
                commit()
            }
        }
        val new6 = view.findViewById<TextView>(R.id.news_6)
        val temp6: News = news[5]
        new6.text = temp6.header
        new6.setOnClickListener {
            parentFragmentManager.beginTransaction().apply {
                replace(R.id.fragment_container, news_detail.newInstance(temp6))
                addToBackStack(null)
                commit()
            }
        }
    }
}