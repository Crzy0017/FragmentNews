package com.example.fragmentnews

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment

private const val NEWS_KEY = "Key"
class news_detail : Fragment(R.layout.fragment_data) {

    companion object {
        fun newInstance(new: News) = news_detail().apply {
            arguments = Bundle().apply {
                putSerializable(NEWS_KEY, new)
            }
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val news: News = arguments?.getSerializable(NEWS_KEY) as News

        view.findViewById<TextView>(R.id.header).text = news.header
        view.findViewById<TextView>(R.id.author).text = news.author
        view.findViewById<TextView>(R.id.content).text = news.content
    }
}